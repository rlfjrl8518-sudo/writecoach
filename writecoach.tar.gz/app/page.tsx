'use client';
import { useState, useEffect } from 'react';
import { loadDB, saveDB, loadSettings, mergeExpressions, mergeWeaknesses } from '@/lib/db';
import { analyzeText } from '@/lib/openai';
import type { Analysis, WriteType } from '@/lib/db';

const TYPES: WriteType[] = ['에세이','일기','기획서','논설','소설','리뷰','기타'];

function ScoreColor(s: number) {
  return s >= 80 ? 'var(--seaweed)' : s >= 60 ? 'var(--gold)' : 'var(--coral-red)';
}

function BreakdownBar({ label, value, max = 20 }: { label: string; value: number; max?: number }) {
  const pct = Math.round((value / max) * 100);
  const fillClass = pct >= 70 ? '' : pct >= 45 ? 'px-bar-fill-gold' : 'px-bar-fill-red';
  return (
    <div style={{ marginBottom: 10 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
        <span style={{ fontSize: 11, color: 'var(--text-muted)' }}>{label}</span>
        <span className="pixel-font" style={{ fontSize: 9, color: pct >= 70 ? 'var(--biolum)' : pct >= 45 ? 'var(--gold)' : 'var(--coral-red)' }}>
          {value}/{max}
        </span>
      </div>
      <div className="px-bar-wrap">
        <div className={`px-bar-fill ${fillClass}`} style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}

export default function WritePage() {
  const today = new Date().toISOString().split('T')[0];
  const [date, setDate] = useState(today);
  const [type, setType] = useState<WriteType>('에세이');
  const [topic, setTopic] = useState('');
  const [text, setText] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<Analysis | null>(null);
  const [err, setErr] = useState('');
  const [saved, setSaved] = useState(false);

  const charCount = text.length;

  async function handleAnalyze() {
    const s = loadSettings();
    if (!s.apiKey) { setErr('설정 탭에서 OpenAI API 키를 먼저 입력해주세요.'); return; }
    if (!text.trim()) { setErr('글을 작성해주세요.'); return; }
    setLoading(true); setErr(''); setResult(null);
    try {
      const res = await analyzeText(s.apiKey, s.model, type, topic, text);
      setResult(res);
      const db = loadDB();
      db.logs.push({ id: Date.now(), date, type, topic, text, status: '분석완료', analysis: res, createdAt: new Date().toISOString() });
      mergeExpressions(db, res.expressions || []);
      mergeWeaknesses(db, res.weaknesses || []);
      saveDB(db);
      clearForm();
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    } catch (e: any) {
      setErr('분석 오류: ' + e.message);
    } finally { setLoading(false); }
  }

  function handleSaveOnly() {
    if (!text.trim()) { setErr('글을 작성해주세요.'); return; }
    const db = loadDB();
    db.logs.push({ id: Date.now(), date, type, topic, text, status: '미분석', createdAt: new Date().toISOString() });
    saveDB(db);
    clearForm();
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  }

  function clearForm() {
    setText(''); setTopic(''); setDate(today);
  }

  return (
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 }}>
      {/* LEFT — 입력 */}
      <div>
        <div className="px-sec-title" style={{ marginBottom: 14 }}>✦ NEW ENTRY</div>
        <div className="px-card">
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 12 }}>
            <div>
              <label className="px-label">날짜</label>
              <input className="px-input" type="date" value={date} onChange={e => setDate(e.target.value)} />
            </div>
            <div>
              <label className="px-label">유형</label>
              <select className="px-select" value={type} onChange={e => setType(e.target.value as WriteType)}>
                {TYPES.map(t => <option key={t}>{t}</option>)}
              </select>
            </div>
          </div>
          <div style={{ marginBottom: 12 }}>
            <label className="px-label">주제</label>
            <input className="px-input" placeholder="핵심 주제를 입력해주세요" value={topic} onChange={e => setTopic(e.target.value)} />
          </div>
          <div style={{ marginBottom: 12 }}>
            <label className="px-label">본문</label>
            <textarea className="px-textarea" rows={12} placeholder="여기에 글을 작성해주세요..." value={text} onChange={e => setText(e.target.value)} />
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap' }}>
            <button className="px-btn px-btn-gold" onClick={handleAnalyze} disabled={loading}>
              {loading ? '분석 중...' : '✦ AI 분석'}
            </button>
            <button className="px-btn px-btn-ghost" onClick={handleSaveOnly} disabled={loading}>저장만</button>
            <span style={{ marginLeft: 'auto', fontSize: 10, color: 'var(--text-dim)', fontFamily: "'Press Start 2P', monospace" }}>
              {charCount.toLocaleString()}자
            </span>
          </div>
          {err && <div style={{ marginTop: 10, fontSize: 11, color: 'var(--coral-red)', lineHeight: 1.6 }}>{err}</div>}
          {saved && <div style={{ marginTop: 10, fontSize: 11, color: 'var(--seaweed)' }}>✓ 저장되었어요!</div>}
        </div>
      </div>

      {/* RIGHT — 결과 */}
      <div>
        <div className="px-sec-title" style={{ marginBottom: 14 }}>✦ ANALYSIS RESULT</div>
        <div className="px-card" style={{ minHeight: 300 }}>
          {loading && (
            <div>
              <div className="px-loader"><span /><span /><span /></div>
              <p style={{ textAlign: 'center', fontSize: 11, color: 'var(--text-muted)', marginTop: 0 }}>AI가 글을 읽고 있어요...</p>
            </div>
          )}
          {!loading && !result && (
            <div style={{ textAlign: 'center', padding: '48px 0' }}>
              <div className="pixel-font" style={{ fontSize: 14, color: 'var(--text-dim)', marginBottom: 12 }}>◈</div>
              <p style={{ fontSize: 11, color: 'var(--text-dim)', lineHeight: 1.8 }}>글을 작성하고<br />AI 분석 버튼을 눌러주세요</p>
            </div>
          )}
          {result && (
            <div>
              {/* 종합 점수 */}
              <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 16 }}>
                <div className="px-score" style={{ borderColor: ScoreColor(result.score), color: ScoreColor(result.score), boxShadow: `2px 2px 0 ${ScoreColor(result.score)}` }}>
                  {result.score}
                </div>
                <div>
                  <div className="pixel-font" style={{ fontSize: 8, color: 'var(--text-muted)', marginBottom: 4 }}>TOTAL SCORE</div>
                  <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>/ 100점</div>
                </div>
              </div>

              <div className="px-divider" />

              {/* 항목별 점수 */}
              {result.score_breakdown && (
                <div style={{ marginBottom: 16 }}>
                  <div className="pixel-font" style={{ fontSize: 8, color: 'var(--text-muted)', marginBottom: 10 }}>BREAKDOWN</div>
                  {Object.entries(result.score_breakdown).map(([k, v]) => (
                    <BreakdownBar key={k} label={k} value={v as number} />
                  ))}
                </div>
              )}

              <div className="px-divider" />

              {/* 장점 */}
              <div style={{ marginBottom: 12 }}>
                <div className="pixel-font" style={{ fontSize: 8, color: 'var(--seaweed)', marginBottom: 6 }}>STRENGTHS</div>
                <div>{(result.strengths || []).map(s => <span key={s} className="px-tag-good">{s}</span>)}</div>
              </div>

              {/* 약점 */}
              <div style={{ marginBottom: 12 }}>
                <div className="pixel-font" style={{ fontSize: 8, color: 'var(--coral-red)', marginBottom: 6 }}>WEAKNESSES</div>
                <div>{(result.weaknesses || []).map(w => <span key={w} className="px-tag-weak">{w}</span>)}</div>
              </div>

              {/* 표현 */}
              {result.expressions?.length > 0 && (
                <div style={{ marginBottom: 12 }}>
                  <div className="pixel-font" style={{ fontSize: 8, color: 'var(--water)', marginBottom: 6 }}>EXPRESSIONS</div>
                  <div>{result.expressions.map(e => <span key={e.text} className="px-tag-expr" title={e.alternative?.join(' / ')}>{e.text}</span>)}</div>
                </div>
              )}

              <div className="px-divider" />

              {/* 개선 제안 */}
              <div>
                <div className="pixel-font" style={{ fontSize: 8, color: 'var(--biolum-soft)', marginBottom: 8 }}>SUGGESTIONS</div>
                {(result.improvement_suggestions || []).map((s, i) => (
                  <div key={i} style={{ fontSize: 12, color: 'var(--text)', lineHeight: 1.7, marginBottom: 6, paddingLeft: 12, borderLeft: '2px solid var(--biolum)' }}>
                    {s}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
