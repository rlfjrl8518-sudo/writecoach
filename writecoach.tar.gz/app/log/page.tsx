'use client';
import { useState, useEffect } from 'react';
import { loadDB, saveDB } from '@/lib/db';
import type { LogEntry } from '@/lib/db';
import Link from 'next/link';

export default function LogPage() {
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [filter, setFilter] = useState('전체');

  useEffect(() => { setLogs([...loadDB().logs].reverse()); }, []);

  function deleteLog(id: number) {
    if (!confirm('이 글을 삭제할까요?')) return;
    const db = loadDB();
    db.logs = db.logs.filter(l => l.id !== id);
    saveDB(db);
    setLogs([...db.logs].reverse());
  }

  const types = ['전체', '에세이', '일기', '기획서', '논설', '소설', '리뷰', '기타'];
  const filtered = filter === '전체' ? logs : logs.filter(l => l.type === filter);

  function scoreColor(s: number) {
    return s >= 80 ? 'var(--seaweed)' : s >= 60 ? 'var(--gold)' : 'var(--coral-red)';
  }

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
        <div>
          <div className="px-sec-title" style={{ marginBottom: 4 }}>✦ WRITING LOG</div>
          <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>총 {logs.length}편 · 분석완료 {logs.filter(l => l.status === '분석완료').length}편</div>
        </div>
        <Link href="/">
          <button className="px-btn px-btn-ghost">+ 새 글 작성</button>
        </Link>
      </div>

      {/* 필터 */}
      <div style={{ display: 'flex', gap: 6, marginBottom: 16, flexWrap: 'wrap' }}>
        {types.map(t => (
          <button key={t} onClick={() => setFilter(t)} className="pixel-font" style={{
            padding: '4px 10px', fontSize: 8, cursor: 'pointer', border: 'none',
            background: filter === t ? 'var(--water)' : 'var(--ocean-mid)',
            color: filter === t ? 'var(--ocean-deep)' : 'var(--text-muted)',
            borderBottom: filter === t ? '2px solid var(--biolum)' : '2px solid transparent',
          }}>{t}</button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <div className="px-card" style={{ textAlign: 'center', padding: '48px 24px' }}>
          <div className="pixel-font" style={{ fontSize: 12, color: 'var(--text-dim)', marginBottom: 12 }}>◈</div>
          <p style={{ fontSize: 12, color: 'var(--text-dim)', lineHeight: 1.8 }}>아직 작성된 글이 없어요.<br />첫 글을 남겨보시는 건 어떨까요?</p>
        </div>
      ) : (
        <div className="px-card" style={{ padding: 0 }}>
          {/* 헤더 */}
          <div style={{ display: 'grid', gridTemplateColumns: '80px 80px 1fr 180px 56px 70px 40px', gap: 8, padding: '8px 12px', borderBottom: '2px solid var(--ocean-light)' }}>
            {['DATE','TYPE','TOPIC / 미리보기','BREAKDOWN','SCORE','STATUS',''].map(h => (
              <div key={h} className="pixel-font" style={{ fontSize: 7, color: 'var(--text-muted)', letterSpacing: '0.05em' }}>{h}</div>
            ))}
          </div>

          {filtered.map(l => (
            <div key={l.id} style={{
              display: 'grid', gridTemplateColumns: '80px 80px 1fr 180px 56px 70px 40px',
              gap: 8, padding: '10px 12px', borderBottom: '1px solid var(--ocean-surface)',
              alignItems: 'center', cursor: 'default',
              transition: 'background .1s',
            }}
              onMouseEnter={e => (e.currentTarget.style.background = 'var(--ocean-surface)')}
              onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}
            >
              <div style={{ fontSize: 10, color: 'var(--text-muted)' }}>{l.date}</div>
              <div><span className="px-badge px-badge-type">{l.type}</span></div>
              <div>
                <div style={{ fontSize: 12, color: 'var(--text)', marginBottom: 2, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{l.topic || '(주제 없음)'}</div>
                <div style={{ fontSize: 10, color: 'var(--text-dim)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{l.text.substring(0, 60)}{l.text.length > 60 ? '…' : ''}</div>
              </div>

              {/* 미니 breakdown */}
              <div>
                {l.analysis?.score_breakdown ? (
                  <div style={{ display: 'flex', gap: 2, alignItems: 'flex-end', height: 28 }}>
                    {Object.entries(l.analysis.score_breakdown).map(([k, v]) => (
                      <div key={k} title={`${k}: ${v}/20`} style={{
                        flex: 1, height: `${Math.round((v as number) / 20 * 100)}%`,
                        background: (v as number) >= 14 ? 'var(--biolum)' : (v as number) >= 8 ? 'var(--gold)' : 'var(--coral-red)',
                        opacity: 0.8, minHeight: 2,
                      }} />
                    ))}
                  </div>
                ) : <span style={{ fontSize: 10, color: 'var(--text-dim)' }}>—</span>}
              </div>

              <div className="pixel-font" style={{ fontSize: 13, color: l.analysis ? scoreColor(l.analysis.score) : 'var(--text-dim)', textAlign: 'center' }}>
                {l.analysis ? l.analysis.score : '—'}
              </div>

              <div>
                <span className={`px-badge ${l.status === '분석완료' ? 'px-badge-done' : 'px-badge-pending'}`} style={{ fontSize: 7 }}>
                  {l.status === '분석완료' ? '완료' : '미분석'}
                </span>
              </div>

              <div>
                <button onClick={() => deleteLog(l.id)} style={{
                  background: 'transparent', border: 'none', color: 'var(--text-dim)',
                  cursor: 'pointer', fontSize: 12, padding: 4,
                }} title="삭제">✕</button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
