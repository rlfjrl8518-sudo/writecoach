'use client';
import { useState, useEffect, useRef } from 'react';
import { loadSettings, saveSettings, loadDB, saveDB } from '@/lib/db';

export default function SettingsPage() {
  const [apiKey, setApiKey] = useState('');
  const [model, setModel] = useState('gpt-4o-mini');
  const [saved, setSaved] = useState(false);
  const importRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const s = loadSettings();
    setApiKey(s.apiKey || '');
    setModel(s.model || 'gpt-4o-mini');
  }, []);

  function handleSave() {
    saveSettings({ apiKey: apiKey.trim(), model });
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  }

  function handleExport() {
    const db = loadDB();
    const blob = new Blob([JSON.stringify(db, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `writecoach_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
  }

  function handleImport(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => {
      try {
        const data = JSON.parse(ev.target?.result as string);
        if (!data.logs) throw new Error('올바른 형식이 아니에요.');
        if (!confirm(`${data.logs.length}편의 글 데이터를 가져올까요? 기존 데이터는 덮어써져요.`)) return;
        saveDB(data);
        alert('가져오기 완료!');
      } catch (err: any) { alert('오류: ' + err.message); }
    };
    reader.readAsText(file);
    e.target.value = '';
  }

  function handleClear() {
    if (!confirm('모든 데이터를 삭제할까요? 되돌릴 수 없어요.')) return;
    localStorage.removeItem('wc_v2_data');
    alert('초기화 완료');
  }

  const Section = ({ title, children }: { title: string; children: React.ReactNode }) => (
    <div style={{ marginBottom: 28 }}>
      <div className="pixel-font" style={{ fontSize: 8, color: 'var(--biolum-soft)', borderBottom: '1px solid var(--ocean-light)', paddingBottom: 8, marginBottom: 14, letterSpacing: '0.1em' }}>
        {title}
      </div>
      {children}
    </div>
  );

  return (
    <div style={{ maxWidth: 520 }}>
      <div className="px-sec-title" style={{ marginBottom: 20 }}>✦ SETTINGS</div>
      <div className="px-card">

        <Section title="OPENAI API">
          <div style={{ marginBottom: 12 }}>
            <label className="px-label">API Key</label>
            <input className="px-input" type="password" placeholder="sk-..." value={apiKey} onChange={e => setApiKey(e.target.value)} style={{ fontFamily: 'monospace' }} />
          </div>
          <div style={{ marginBottom: 14 }}>
            <label className="px-label">모델</label>
            <select className="px-select" value={model} onChange={e => setModel(e.target.value)}>
              <option value="gpt-4o-mini">gpt-4o-mini — 빠르고 저렴 (추천)</option>
              <option value="gpt-4o">gpt-4o — 더 정확, 비용 높음</option>
            </select>
          </div>
          <button className="px-btn px-btn-gold" onClick={handleSave}>저장</button>
          {saved && <span style={{ marginLeft: 12, fontSize: 11, color: 'var(--seaweed)' }}>✓ 저장됐어요!</span>}
          <div style={{ marginTop: 12, fontSize: 10, color: 'var(--text-dim)', lineHeight: 1.8, padding: '10px 12px', background: 'var(--ocean-deep)', borderLeft: '2px solid var(--ocean-light)' }}>
            <span style={{ color: 'var(--gold)' }}>보안:</span> API 키는 이 기기의 브라우저 저장소에만 저장돼요. 서버로 전송되지 않아요.
          </div>
        </Section>

        <div className="px-divider" />

        <Section title="DATA MANAGEMENT">
          <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', marginBottom: 12 }}>
            <button className="px-btn-ghost" onClick={handleExport}>↓ JSON 내보내기</button>
            <button className="px-btn-ghost" onClick={() => importRef.current?.click()}>↑ JSON 가져오기</button>
          </div>
          <input ref={importRef} type="file" accept=".json" style={{ display: 'none' }} onChange={handleImport} />
          <div style={{ fontSize: 10, color: 'var(--text-dim)', lineHeight: 1.8, padding: '10px 12px', background: 'var(--ocean-deep)', borderLeft: '2px solid var(--ocean-light)' }}>
            다른 기기에서 사용하려면 JSON 내보내기 후 가져오기 하세요.<br />
            <span style={{ color: 'var(--gold)' }}>폰 → 노트북:</span> 폰에서 내보내기 → 노트북에서 가져오기
          </div>
        </Section>

        <div className="px-divider" />

        <Section title="DANGER ZONE">
          <button className="px-btn px-btn-danger" onClick={handleClear}>전체 데이터 초기화</button>
          <div style={{ marginTop: 8, fontSize: 10, color: 'var(--text-dim)' }}>이 작업은 되돌릴 수 없어요.</div>
        </Section>

      </div>
    </div>
  );
}
