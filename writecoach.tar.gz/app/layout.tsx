'use client';
import './globals.css';
import Link from 'next/link';
import { usePathname } from 'next/navigation';

const TABS = [
  { href: '/',          label: 'WRITE' },
  { href: '/log',       label: 'LOG'   },
  { href: '/dashboard', label: 'DASH'  },
  { href: '/report',    label: 'REPORT'},
  { href: '/settings',  label: 'SET'   },
];

export default function RootLayout({ children }: { children: React.ReactNode }) {
  const path = usePathname();
  return (
    <html lang="ko">
      <head>
        <title>WriteCoach</title>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
      </head>
      <body>
        {/* NAV */}
        <nav style={{
          background: 'var(--ocean-surface)',
          borderBottom: '2px solid var(--water)',
          padding: '0 20px',
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          height: 48, position: 'sticky', top: 0, zIndex: 100,
        }}>
          <div className="pixel-font" style={{ fontSize: 11, color: 'var(--gold)', letterSpacing: '0.05em' }}>
            ✦ WRITE<span style={{ color: 'var(--text-muted)' }}>coach</span>
          </div>
          <div style={{ display: 'flex', gap: 2 }}>
            {TABS.map(t => {
              const active = t.href === '/' ? path === '/' : path.startsWith(t.href);
              return (
                <Link key={t.href} href={t.href} style={{
                  padding: '6px 12px', fontSize: 8, textDecoration: 'none',
                  fontFamily: "'Press Start 2P', monospace",
                  background: active ? 'var(--water)' : 'transparent',
                  color: active ? 'var(--ocean-deep)' : 'var(--text-muted)',
                  transition: 'all .1s',
                }}>
                  {t.label}
                </Link>
              );
            })}
          </div>
        </nav>

        {/* MAIN */}
        <main style={{ maxWidth: 1080, margin: '0 auto', padding: '24px 20px', minHeight: 'calc(100vh - 48px)' }}>
          {children}
        </main>

        {/* FOOTER */}
        <div style={{ textAlign: 'center', padding: '12px', borderTop: '1px solid var(--ocean-surface)' }}>
          <span className="pixel-font" style={{ fontSize: 7, color: 'var(--text-dim)' }}>
            ✦ WRITECOACH — YOUR WRITING JOURNEY
          </span>
        </div>
      </body>
    </html>
  );
}
