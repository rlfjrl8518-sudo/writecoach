'use client';
import { useState, useEffect } from 'react';
import { loadDB, getMonthlyStats, getAvgBreakdown, getAvgSenses, getTopExpressions, getTopWeaknesses } from '@/lib/db';
import { RadarChart, Radar, PolarGrid, PolarAngleAxis, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Cell } from 'recharts';

const GOLD = '#f39c12'; const TEAL = '#00e5ff'; const RED = '#e74c3c'; const WATER = '#1e8bc3'; const GREEN = '#27ae60';

export default function DashboardPage() {
  const [db, setDb] = useState(() => loadDB());
  useEffect(() => { setDb(loadDB()); }, []);

  const logs = db.logs;
  const analyzed = logs.filter(l => l.analysis);
  const scores = analyzed.map(l => l.analysis!.score);
  const avg = scores.length ? Math.round(scores.reduce((a, b) => a + b) / scores.length) : null;
  const totalChars = logs.reduce((s, l) => s + l.text.length, 0);
  const monthly = getMonthlyStats(db);
  const breakdown = getAvgBreakdown(db);
  const senses = getAvgSenses(db);
  const topWeak = getTopWeaknesses(db, 10);
  const topExpr = getTopExpressions(db, 10);

  const radarData = breakdown ? Object.entries(breakdown).map(([k, v]) => ({ subject: k, value: v, fullMark: 20 })) : [];
  const senseData = senses ? Object.entries(senses).map(([k, v]) => ({ name: k, value: v })) : [];

  function scoreColor(s: number | null) {
    if (!s) return TEAL;
    return s >= 80 ? GREEN : s >= 60 ? GOLD : RED;
  }

  const StatCard = ({ label, value, sub, color = GOLD }: { label: string; value: string | number; sub?: string; color?: string }) => (
    <div className="px-card" style={{ textAlign: 'center' }}>
      <div className="pixel-font" style={{ fontSize: 22, color, marginBottom: 4, lineHeight: 1.2 }}>{value}</div>
      <div style={{ fontSize: 10, color: 'var(--text-muted)' }}>{label}</div>
      {sub && <div style={{ fontSize: 9, color: 'var(--text-dim)', marginTop: 2 }}>{sub}</div>}
    </div>
  );

  return (
    <div>
      <div className="px-sec-title" style={{ marginBottom: 20 }}>✦ DASHBOARD</div>

      {/* STAT CARDS */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, marginBottom: 24 }}>
        <StatCard label="총 작성 편수" value={logs.length} sub="편" />
        <StatCard label="누적 글자 수" value={totalChars.toLocaleString()} sub="자" color={TEAL} />
        <StatCard label="평균 점수" value={avg ?? '—'} sub="/ 100" color={scoreColor(avg)} />
        <StatCard label="분석 완료" value={analyzed.length} sub={`/ ${logs.length}편`} color={GREEN} />
      </div>

      {/* CHARTS ROW 1 */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 16 }}>

        {/* 월별 점수 */}
        <div className="px-card-teal" style={{ padding: 16 }}>
          <div className="pixel-font" style={{ fontSize: 8, color: 'var(--biolum-soft)', marginBottom: 12 }}>MONTHLY SCORE</div>
          {monthly.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '32px 0', fontSize: 11, color: 'var(--text-dim)' }}>데이터 없음</div>
          ) : (
            <ResponsiveContainer width="100%" height={180}>
              <BarChart data={monthly} barSize={24}>
                <XAxis dataKey="month" tick={{ fill: '#7fb3d3', fontSize: 9 }} axisLine={false} tickLine={false} />
                <YAxis domain={[0, 100]} tick={{ fill: '#7fb3d3', fontSize: 9 }} axisLine={false} tickLine={false} />
                <Tooltip
                  contentStyle={{ background: 'var(--ocean-mid)', border: '1px solid var(--ocean-light)', fontSize: 11 }}
                  labelStyle={{ color: 'var(--biolum)' }} itemStyle={{ color: GOLD }}
                />
                <Bar dataKey="avg" radius={[2, 2, 0, 0]}>
                  {monthly.map((m, i) => (
                    <Cell key={i} fill={m.avg >= 80 ? GREEN : m.avg >= 60 ? GOLD : RED} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          )}
        </div>

        {/* 레이더 차트 */}
        <div className="px-card-gold" style={{ padding: 16 }}>
          <div className="pixel-font" style={{ fontSize: 8, color: 'var(--gold)', marginBottom: 12 }}>SKILL RADAR</div>
          {radarData.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '32px 0', fontSize: 11, color: 'var(--text-dim)' }}>분석 데이터 없음</div>
          ) : (
            <ResponsiveContainer width="100%" height={180}>
              <RadarChart data={radarData}>
                <PolarGrid stroke="#1a5276" />
                <PolarAngleAxis dataKey="subject" tick={{ fill: '#7fb3d3', fontSize: 9 }} />
                <Radar dataKey="value" stroke={GOLD} fill={GOLD} fillOpacity={0.25} />
              </RadarChart>
            </ResponsiveContainer>
          )}
        </div>
      </div>

      {/* CHARTS ROW 2 */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 16 }}>

        {/* 약점 TOP10 */}
        <div className="px-card" style={{ padding: 16 }}>
          <div className="pixel-font" style={{ fontSize: 8, color: RED, marginBottom: 12 }}>WEAKNESS TOP 10</div>
          {topWeak.length === 0 ? (
            <div style={{ fontSize: 11, color: 'var(--text-dim)', padding: '16px 0' }}>아직 데이터가 없어요</div>
          ) : topWeak.map(([name, count], i) => {
            const maxVal = topWeak[0]?.[1] || 1;
            return (
              <div key={name} style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
                <span className="pixel-font" style={{ fontSize: 8, color: i < 3 ? RED : 'var(--text-dim)', width: 16 }}>{i + 1}</span>
                <span style={{ flex: 1, fontSize: 11, color: 'var(--text)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{name}</span>
                <div className="px-bar-wrap" style={{ width: 60 }}>
                  <div className="px-bar-fill px-bar-fill-red" style={{ width: `${Math.round(count / maxVal * 100)}%` }} />
                </div>
                <span className="pixel-font" style={{ fontSize: 8, color: 'var(--text-muted)', width: 28, textAlign: 'right' }}>{count}회</span>
              </div>
            );
          })}
        </div>

        {/* 표현 TOP10 */}
        <div className="px-card" style={{ padding: 16 }}>
          <div className="pixel-font" style={{ fontSize: 8, color: TEAL, marginBottom: 12 }}>EXPRESSION TOP 10</div>
          {topExpr.length === 0 ? (
            <div style={{ fontSize: 11, color: 'var(--text-dim)', padding: '16px 0' }}>아직 데이터가 없어요</div>
          ) : topExpr.map(([name, data], i) => {
            const maxVal = topExpr[0]?.[1].count || 1;
            return (
              <div key={name} style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
                <span className="pixel-font" style={{ fontSize: 8, color: i < 3 ? GOLD : 'var(--text-dim)', width: 16 }}>{i + 1}</span>
                <span style={{ flex: 1, fontSize: 11, color: 'var(--text)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{name}</span>
                <div className="px-bar-wrap" style={{ width: 60 }}>
                  <div className="px-bar-fill" style={{ width: `${Math.round(data.count / maxVal * 100)}%` }} />
                </div>
                <span className="pixel-font" style={{ fontSize: 8, color: 'var(--text-muted)', width: 28, textAlign: 'right' }}>{data.count}회</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* 감각 분포 */}
      {senseData.length > 0 && (
        <div className="px-card" style={{ padding: 16 }}>
          <div className="pixel-font" style={{ fontSize: 8, color: 'var(--biolum-soft)', marginBottom: 12 }}>SENSE DISTRIBUTION (평균)</div>
          <div style={{ display: 'flex', gap: 16, alignItems: 'flex-end', height: 80 }}>
            {senseData.map((s, i) => {
              const pct = Math.round((s.value / 5) * 100);
              const colors = [WATER, TEAL, GREEN, GOLD, RED];
              return (
                <div key={s.name} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4 }}>
                  <span className="pixel-font" style={{ fontSize: 7, color: colors[i] }}>{s.value.toFixed(1)}</span>
                  <div style={{ width: '100%', background: 'var(--ocean-deep)', border: '2px solid var(--ocean-light)', height: 56, display: 'flex', alignItems: 'flex-end', overflow: 'hidden' }}>
                    <div style={{ width: '100%', height: `${pct}%`, background: colors[i], opacity: 0.8 }} />
                  </div>
                  <span style={{ fontSize: 10, color: 'var(--text-muted)' }}>{s.name}</span>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
