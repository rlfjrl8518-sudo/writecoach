'use client';
import { useState } from 'react';
import { loadDB, loadSettings, getTopWeaknesses, getTopExpressions, getAvgBreakdown, getAvgSenses } from '@/lib/db';
import { generateMonthlyReport } from '@/lib/openai';

export default function ReportPage() {
  const [report, setReport] = useState('');
  const [loading, setLoading] = useState(false);
  const [month, setMonth] = useState(() => new Date().toISOString().substring(0, 7));
  const [err, setErr] = useState('');

  async function handleGenerate() {
    const s = loadSettings();
    if (!s.apiKey) { setErr('설정 탭에서 API 키를 먼저 입력해주세요.'); return; }
    setLoading(true); setErr(''); setReport('');

    const db = loadDB();
    const monthLogs = db.logs.filter(l => l.date.startsWith(month) && l.analysis);
    if (monthLogs.length === 0) { setErr(`${month} 월에 분석된 글이 없어요.`); setLoading(false); return; }

    const scores = monthLogs.map(l => l.analysis!.score);
    const breakdown = getAvgBreakdown({ ...db, logs: monthLogs });
    const senses = getAvgSenses({ ...db, logs: monthLogs });
    const allWords = monthLogs.flatMap(l => l.analysis!.repeated_words || []);
    const wordCount: Record<string, number> = {};
    allWords.forEach(w => { wordCount[w] = (wordCount[w] || 0) + 1; });
    const top10Words = Object.entries(wordCount).sort((a, b) => b[1] - a[1]).slice(0, 10).map(([w]) => w);

    const payload = {
      year: month.substring(0, 4), month: month.substring(5, 7),
      total_count: monthLogs.length,
      avg_score: Math.round(scores.reduce((a, b) => a + b) / scores.length),
      max_score: Math.max(...scores), min_score: Math.min(...scores),
      score_breakdown_avg: breakdown,
      senses_avg: senses,
      top5_expressions: getTopExpressions({ ...db, logs: monthLogs }, 5).map(([k, v]) => `${k}(${v.count}회)`),
      top10_repeated_words: top10Words,
      top5_weaknesses: getTopWeaknesses({ ...db, logs: monthLogs }, 5).map(([k, v]) => `${k}(${v}회)`),
    };

    try {
      const text = await generateMonthlyReport(s.apiKey, s.model, payload);
      setReport(text);
    } catch (e: any) {
      setErr('오류: ' + e.message);
    } finally { setLoading(false); }
  }

  function renderReport(text: string) {
    const sections = text.split(/^###\s+/m).filter(Boolean);
    return sections.map((sec, i) => {
      const [title, ...body] = sec.split('\n');
      return (
        <div key={i} style={{ marginBottom: 24, paddingBottom: 20, borderBottom: '1px solid var(--ocean-surface)' }}>
          <div className="pixel-font" style={{ fontSize: 9, color: 'var(--gold)', marginBottom: 10, letterSpacing: '0.05em' }}>
            {i + 1}. {title.trim().toUpperCase()}
          </div>
          <div style={{ fontSize: 13, color: 'var(--text)', lineHeight: 1.85, fontFamily: "'Pretendard', sans-serif", whiteSpace: 'pre-wrap' }}>
            {body.join('\n').trim()}
          </div>
        </div>
      );
    });
  }

  return (
    <div style={{ maxWidth: 760, margin: '0 auto' }}>
      <div className="px-sec-title" style={{ marginBottom: 20 }}>✦ MONTHLY REPORT</div>

      <div className="px-card" style={{ marginBottom: 20 }}>
        <div style={{ display: 'flex', gap: 12, alignItems: 'flex-end', flexWrap: 'wrap' }}>
          <div style={{ flex: '0 0 160px' }}>
            <label className="px-label">분석 월</label>
            <input className="px-input" type="month" value={month} onChange={e => setMonth(e.target.value)} />
          </div>
          <button className="px-btn px-btn-gold" onClick={handleGenerate} disabled={loading}>
            {loading ? '생성 중...' : '✦ 리포트 생성'}
          </button>
        </div>
        {err && <div style={{ marginTop: 10, fontSize: 11, color: 'var(--coral-red)' }}>{err}</div>}
      </div>

      {loading && (
        <div className="px-card" style={{ textAlign: 'center' }}>
          <div className="px-loader"><span /><span /><span /></div>
          <p style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 0 }}>한 달치 데이터를 분석하고 있어요...</p>
        </div>
      )}

      {report && (
        <div className="px-card-teal" style={{ padding: 24 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
            <div className="pixel-font" style={{ fontSize: 9, color: 'var(--biolum)' }}>{month} 월간 리포트</div>
            <button className="px-btn-ghost" onClick={() => {
              const blob = new Blob([report], { type: 'text/plain' });
              const a = document.createElement('a');
              a.href = URL.createObjectURL(blob);
              a.download = `writecoach_report_${month}.txt`;
              a.click();
            }} style={{ fontSize: 9 }}>저장</button>
          </div>
          <div className="px-divider" />
          <div style={{ marginTop: 16 }}>{renderReport(report)}</div>
        </div>
      )}

      {!loading && !report && (
        <div style={{ textAlign: 'center', padding: '48px 0' }}>
          <div className="pixel-font" style={{ fontSize: 12, color: 'var(--text-dim)', marginBottom: 12 }}>◈</div>
          <p style={{ fontSize: 12, color: 'var(--text-dim)', lineHeight: 1.8 }}>분석할 월을 선택하고<br />리포트 생성 버튼을 눌러주세요</p>
          <p style={{ fontSize: 10, color: 'var(--text-dim)', marginTop: 8 }}>해당 월에 분석된 글이 1편 이상 있어야 해요</p>
        </div>
      )}
    </div>
  );
}
