import type { Analysis } from './db';

const SYSTEM_PROMPT = `너는 30년 경력의 전문 작가이자 카피라이터다.
사용자의 글쓰기 습관을 분석하고 장기적으로 성장 데이터를 축적하는 것이 목표다.

[표현 분류] 평가 / 감정 / 행동 / 상태 / 묘사
[구조 분류] 장소→대상 / 대상→상태 / 주체→행동 / 행동→결과 / 원인→결과 / 감상→설명
[감각 분류] 시각 / 청각 / 후각 / 미각 / 촉각

[평가 기준 및 배점 — 각 항목 0-20점]
- 표현력: 어휘 선택의 적절성, 참신성
- 전달력: 독자에게 의미가 명확히 전달되는가
- 문장다양성: 문장 길이와 구조의 다양성
- 구체성: 추상적 표현 대신 구체적 사례/묘사 사용
- 묘사력: 감각적 묘사의 풍부함
- 구조다양성: 다양한 문장 구조 패턴 사용

score = round(score_breakdown 합산 / 120 * 100)

[말투 규칙]
- 판단과 피드백은 데이터 기반으로 냉철하게, 근거 없는 칭찬 절대 금지
- 사용자에게 전달하는 strengths/weaknesses/improvement_suggestions의 문장은 따뜻하고 상냥하게
- 단정 지시형("~해라") 금지 → 제안형("~해보시면 어떨까요") 사용

반드시 아래 JSON 형식으로만 응답하라. 마크다운 코드블록 절대 금지.`;

const USER_PROMPT = (type: string, topic: string, text: string) => `
유형: ${type || '미지정'}
주제: ${topic || '미지정'}
본문:
${text}

응답 JSON:
{
  "score": 0,
  "score_breakdown": { "표현력":0,"전달력":0,"문장다양성":0,"구체성":0,"묘사력":0,"구조다양성":0 },
  "strengths": ["키워드1","키워드2"],
  "weaknesses": ["키워드1","키워드2"],
  "repeated_words": ["단어1","단어2"],
  "expressions": [{ "text":"표현","category":"평가|감정|행동|상태|묘사","alternative":["대체1"] }],
  "structures": [{ "type":"원인→결과","example":"실제 문장" }],
  "senses": { "시각":0,"청각":0,"후각":0,"미각":0,"촉각":0 },
  "improvement_suggestions": ["제안1","제안2"]
}`;

export async function analyzeText(
  apiKey: string,
  model: string,
  type: string,
  topic: string,
  text: string,
): Promise<Analysis> {
  const res = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${apiKey}` },
    body: JSON.stringify({
      model,
      max_tokens: 1800,
      temperature: 0.3,
      messages: [
        { role: 'system', content: SYSTEM_PROMPT },
        { role: 'user', content: USER_PROMPT(type, topic, text) },
      ],
    }),
  });
  const data = await res.json();
  if (data.error) throw new Error(data.error.message);
  const raw = data.choices[0].message.content.trim()
    .replace(/^```json\s*/i, '').replace(/^```\s*/i, '').replace(/```\s*$/i, '').trim();
  return JSON.parse(raw) as Analysis;
}

/* 월간 리포트 */
export async function generateMonthlyReport(apiKey: string, model: string, payload: object): Promise<string> {
  const prompt = `너는 사용자의 글쓰기 코치다.
다음 데이터를 기반으로 월간 성장 리포트를 작성하라.
데이터 기반으로만 분석하고 근거 없는 칭찬은 하지 마라.
사용자에게 전달하는 말투는 따뜻하고 상냥하게 유지하라.

${JSON.stringify(payload, null, 2)}

반드시 아래 순서로 작성한다:
1. 이번 달 성장 요약
2. 가장 발전한 부분
3. 가장 부족한 부분
4. 반복되는 문제점
5. 다음 달 집중 과제
6. 추천 글쓰기 훈련 과제 3개

각 섹션은 ### 섹션명 으로 구분하라.`;

  const res = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${apiKey}` },
    body: JSON.stringify({
      model, max_tokens: 2000, temperature: 0.4,
      messages: [{ role: 'user', content: prompt }],
    }),
  });
  const data = await res.json();
  if (data.error) throw new Error(data.error.message);
  return data.choices[0].message.content;
}
