// ────────────────────────────────────────────────
//  WriteCoach — DB (localStorage)
// ────────────────────────────────────────────────

export type WriteType = '에세이' | '일기' | '기획서' | '논설' | '소설' | '리뷰' | '기타';

export interface ScoreBreakdown {
  표현력: number; 전달력: number; 문장다양성: number;
  구체성: number; 묘사력: number; 구조다양성: number;
}
export interface SenseCount {
  시각: number; 청각: number; 후각: number; 미각: number; 촉각: number;
}
export interface Expression {
  text: string; category: string; alternative: string[];
}
export interface Structure {
  type: string; example: string;
}
export interface Analysis {
  score: number;
  score_breakdown: ScoreBreakdown;
  strengths: string[];
  weaknesses: string[];
  repeated_words: string[];
  expressions: Expression[];
  structures: Structure[];
  senses: SenseCount;
  improvement_suggestions: string[];
}
export interface LogEntry {
  id: number;
  date: string;
  type: WriteType;
  topic: string;
  text: string;
  status: '미분석' | '분석완료';
  analysis?: Analysis;
  createdAt: string;
}
export interface ExpressionRecord {
  count: number; category: string; alternatives: string[];
}
export interface DB {
  logs: LogEntry[];
  expressions: Record<string, ExpressionRecord>;
  weaknesses: Record<string, number>;
}

const DB_KEY = 'wc_v2_data';

export function loadDB(): DB {
  if (typeof window === 'undefined') return { logs: [], expressions: {}, weaknesses: {} };
  try {
    return JSON.parse(localStorage.getItem(DB_KEY) || 'null') ?? { logs: [], expressions: {}, weaknesses: {} };
  } catch { return { logs: [], expressions: {}, weaknesses: {} }; }
}
export function saveDB(db: DB): void {
  localStorage.setItem(DB_KEY, JSON.stringify(db));
}

/* 정규화 키 */
const normalize = (s: string) => s.trim().replace(/\s+/g, ' ').toLowerCase();

export function mergeExpressions(db: DB, exprs: Expression[]) {
  exprs.forEach(e => {
    if (!e.text) return;
    const key = normalize(e.text);
    if (!db.expressions[key]) db.expressions[key] = { count: 0, category: e.category || '', alternatives: [] };
    db.expressions[key].count++;
    (e.alternative || []).forEach(a => {
      if (!db.expressions[key].alternatives.includes(a)) db.expressions[key].alternatives.push(a);
    });
  });
}
export function mergeWeaknesses(db: DB, list: string[]) {
  list.forEach(w => {
    if (!w) return;
    const key = normalize(w);
    db.weaknesses[key] = (db.weaknesses[key] || 0) + 1;
  });
}

/* 집계 헬퍼 */
export function getAnalyzedLogs(db: DB) { return db.logs.filter(l => l.analysis); }

export function getMonthlyStats(db: DB) {
  const map: Record<string, number[]> = {};
  getAnalyzedLogs(db).forEach(l => {
    const m = l.date.substring(0, 7);
    if (!map[m]) map[m] = [];
    map[m].push(l.analysis!.score);
  });
  return Object.keys(map).sort().map(m => ({
    month: m,
    avg: Math.round(map[m].reduce((a, b) => a + b, 0) / map[m].length),
    count: map[m].length,
  }));
}

export function getAvgBreakdown(db: DB): ScoreBreakdown | null {
  const logs = getAnalyzedLogs(db);
  if (!logs.length) return null;
  const keys: (keyof ScoreBreakdown)[] = ['표현력','전달력','문장다양성','구체성','묘사력','구조다양성'];
  const result = {} as ScoreBreakdown;
  keys.forEach(k => {
    result[k] = Math.round(logs.reduce((s, l) => s + (l.analysis!.score_breakdown?.[k] || 0), 0) / logs.length);
  });
  return result;
}

export function getAvgSenses(db: DB): SenseCount | null {
  const logs = getAnalyzedLogs(db);
  if (!logs.length) return null;
  const keys: (keyof SenseCount)[] = ['시각','청각','후각','미각','촉각'];
  const result = {} as SenseCount;
  keys.forEach(k => {
    result[k] = Math.round((logs.reduce((s, l) => s + (l.analysis!.senses?.[k] || 0), 0) / logs.length) * 10) / 10;
  });
  return result;
}

export function getTopExpressions(db: DB, n = 10) {
  return Object.entries(db.expressions).sort((a, b) => b[1].count - a[1].count).slice(0, n);
}
export function getTopWeaknesses(db: DB, n = 10) {
  return Object.entries(db.weaknesses).sort((a, b) => b[1] - a[1]).slice(0, n);
}

/* Settings */
const SETTINGS_KEY = 'wc_settings';
export interface Settings { apiKey: string; model: string; }
export function loadSettings(): Settings {
  if (typeof window === 'undefined') return { apiKey: '', model: 'gpt-4o-mini' };
  try { return JSON.parse(localStorage.getItem(SETTINGS_KEY) || 'null') ?? { apiKey: '', model: 'gpt-4o-mini' }; }
  catch { return { apiKey: '', model: 'gpt-4o-mini' }; }
}
export function saveSettings(s: Settings) { localStorage.setItem(SETTINGS_KEY, JSON.stringify(s)); }
